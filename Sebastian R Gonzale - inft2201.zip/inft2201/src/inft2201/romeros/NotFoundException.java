package inft2201.romeros;

@SuppressWarnings("serial")
/**
 * The NotFoundException class represents an exception thrown when attempting
 * to retrieve an item that is not found in the system.
 */
public class NotFoundException extends Exception {
    /**
     * Default constructor for NotFoundException.
     */
    public NotFoundException() {
        super();
    }
    /**
     * Constructor for NotFoundException with a custom message.
     *
     * @param message A description of the exception.
     */
    public NotFoundException(String message) {
        super(message);
    }
}
