package inft2201.romeros;
import java.sql.Connection;
import java.text.DateFormat;
//import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Sebastian Romero Gonzalez - 100886859 - Assignment 2
 * Abstract class representing a user with common attributes and behaviors.
 */
public class User implements CollegeInterface{
	
	/**
	 * Initializes the database connection.
	 * @param c The database connection object.
	 */
	public static void initialize(Connection c) {
	    UserDA.initialize(c);
	}

	/**
	 * Terminates the connection to the database.
	 */
    public static void terminate() {
        UserDA.terminate();
    }
	/**
     * Retrieves a user from the database based on the provided ID.
     *
     * @param id The ID of the user to retrieve.
     * @return A user object representing the retrieved user.
     * @throws NotFoundException If the user is not found in the database.
     */
    public static User retrieve(long id) throws NotFoundException {
        return UserDA.retrieve(id);
    }
	/**
     * Creates a new user in the database using the current object's data.
     *
     * @throws DuplicateException If the user already exists in the database.
     */
    public void create() throws DuplicateException {
        UserDA.create(this);
    }
	/**
     * Updates the existing user's information in the database using the current object's data.
     *
     * @throws NotFoundException If the user is not found in the database.
     */
    public void update() throws NotFoundException {
        UserDA.update(this);
    }
	/**
     * Deletes the current user from the database.
     *
     * @throws NotFoundException If the user is not found in the database.
     */
    public void delete() throws NotFoundException {
        UserDA.delete(this);
    }

	// Properties - Class Attributes.
	static final long DEFAULT_ID = 100123456;
	static final String DEFAULT_PASSWORD = "password";
	static final byte MINIMUM_PASSWORD_LENGTH = 8;
	static final byte MAXIMUM_PASSWORD_LENGTH = 40;
	static final String DEFAULT_FIRST_NAME = "John";
	static final String DEFAULT_LAST_NAME = "Doe";
	static final String DEFAULT_EMAIL_ADDRESS = "john.doe@dcmail.com";
	static final boolean DEFAULT_ENABLED_STATUS = true;
	static final char DEFAULT_TYPE = 's';
	static final byte ID_NUMBER_LENGHT = 9;
	static final DateFormat DF = DateFormat.getDateInstance(DateFormat.MEDIUM, Locale.CANADA);
	
	// Instance Attributes.
	private long id;
	private String password;
	private String firstName;
	private String lastName;
	private String emailAddress;
	private Date lastAccess;
	private Date enrolDate;
	private boolean enabled;
	private char type;
	
	// Accessors - Mutators.
	/**
     * Gets the user's ID.
     *
     * @return the id
     */
	public long getId() {
		return id;
	}
	/**
     * Sets the user's ID, throwing an exception if the ID is invalid.
     *
     * @param id the id to set
     * @throws InvalidIdException if the ID is invalid
     */
	public void setId(long id) throws InvalidIdException{
		if(verifyId(id)) {
			throw new InvalidIdException();
		} else {
			this.id = id;
		}
	}
	/**
     * Gets the user's password.
     *
     * @return the password
     */
	public String getPassword() {
		return password;
	}
	 /**
     * Sets the user's password, throwing an exception if the password is invalid.
     *
     * @param password the password to set
     * @throws InvalidPasswordException if the password is invalid
     */
	public void setPassword(String password) throws InvalidPasswordException{
		if (password.length() < MINIMUM_PASSWORD_LENGTH || password.length() > MAXIMUM_PASSWORD_LENGTH) {
			throw new InvalidPasswordException();
		} else {
			this.password = password;
		}
	}
	/**
     * Gets the user's first name.
     *
     * @return the firstName
     */
	public String getFirstName() {
		return firstName;
	}
	/**
     * Sets the user's first name, throwing an exception if the name is invalid.
     *
     * @param firstName the firstName to set
     * @throws InvalidNameException if the name is invalid
     */
	public void setFirstName(String firstName) throws InvalidNameException {
		if (firstName.isEmpty() || isNumeric(firstName)) {
            throw new InvalidNameException();
        }
        this.firstName = firstName;
	}
	/**
     * Gets the user's last name.
     *
     * @return the lastName
     */
	public String getLastName() {
		return lastName;
	}
	/**
     * Sets the user's last name, throwing an exception if the name is invalid.
     *
     * @param lastName the lastName to set
     * @throws InvalidNameException if the name is invalid
     */
	public void setLastName(String lastName) throws InvalidNameException {
		if (lastName.isEmpty() || isNumeric(lastName)) {
            throw new InvalidNameException();
        }
        this.lastName = lastName;
	}
	/**
     * Gets the user's email address.
     *
     * @return the emailAddress
     */
	public String getEmailAddress() {
		return emailAddress;
	}
	/**
     * Sets the user's email address.
     *
     * @param emailAddress the emailAddress to set
     */
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	/**
	 * @return the lastAccess
	 */
	public Date getLastAccess() {
		return lastAccess;
	}
	/**
	 * Sets the last access date for the object.
	 *
	 * @param lastAccess The Date representing the last access date.
	 */
	public void setLastAccess(Date lastAccess) {
		this.lastAccess = lastAccess;
	}
	/**
     * Gets the user's enrollment date.
     *
     * @return the enrolDate
     */
	public Date getEnrolDate() {
		return enrolDate;
	}
	/**
     * Sets the user's enrollment date.
     *
     * @param enrolDate the enrolDate to set
     */
	public void setEnrolDate(Date enrolDate) {
		this.enrolDate = enrolDate;
	}
	/**
     * Checks if the user is enabled.
     *
     * @return true if the user is enabled, false otherwise
     */
	public boolean isEnabled() {
		return enabled;
	}
	/**
     * Sets the user's enabled status.
     *
     * @param enabled the enabled to set
     */
	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}
	/**
     * Gets the user's type.
     *
     * @return the type
     */
	public char getType() {
		return type;
	}
	/**
     * Sets the user's type.
     *
     * @param type the type to set
     */
	public void setType(char type) {

		this.type = type;
	}
	/**
	 * Constructs a User object with specified attributes.
	 *
	 * @param id            The ID of the user.
	 * @param password      The password of the user.
	 * @param firstName     The first name of the user.
	 * @param lastName      The last name of the user.
	 * @param emailAddress  The email address of the user.
	 * @param lastAccess    The last access date of the user.
	 * @param enrolDate     The enrollment date of the user.
	 * @param enabled       The enabled status of the user.
	 * @param type          The type of the user.
	 * @throws InvalidUserDataException If the provided user data is invalid.
	 */
	// Parameterized Constructor.
	public User(
			long id, 
			String password,
			String firstName, 
			String lastName, 
			String emailAddress,
			Date lastAccess,
			Date enrolDate,
			boolean enabled,
			char type
			) throws InvalidUserDataException {
		try {
			setId(id);
			setPassword(password);
			setFirstName(firstName);
			setLastName(lastName);
			setEmailAddress(emailAddress);
			setLastAccess(lastAccess);
			setEnrolDate(enrolDate);
			setEnabled(enabled);
			setType(type);
		}
		catch (InvalidIdException | InvalidPasswordException | InvalidNameException e) {
			throw new InvalidUserDataException("Invalid user data: " + e.getMessage(), e);
	}}
	
	// Default Constructor.
	/**
	 * Constructs a default User object with predefined attributes.
	 * @param type2 
	 * @param enable 
	 * @param emailAddress2 
	 * @param lastName2 
	 * @param firstName2 
	 * @param id2 
	 *
	 * @throws InvalidUserDataException If the default user data is invalid.
	 */
	public User() throws InvalidUserDataException {
		try {	
			this.id = DEFAULT_ID;
			this.setPassword(DEFAULT_PASSWORD);
			this.setFirstName(DEFAULT_FIRST_NAME);
			this.setLastName(DEFAULT_LAST_NAME);
			this.setEmailAddress(DEFAULT_EMAIL_ADDRESS);
			this.setLastAccess(new Date());
			this.setEnrolDate(new Date());
			this.setEnabled(DEFAULT_ENABLED_STATUS);
			this.setType(DEFAULT_TYPE);
		} catch (InvalidPasswordException | InvalidNameException e) {
			throw new InvalidUserDataException("Invalid user data: " + e.getMessage(), e);
		}	
	}
	
	// Instance Methods.
	/**
     * Overrides the toString method to provide formatted user information.
     *
     * @return Formatted string containing user information.
     */
	@Override 
	public String toString() {
        String outString = "User Info for: " + getId() + "\n\t" +
        		"Name:" + getFirstName() + " (" + getEmailAddress() + ") \n\t" +
        		"Created on: " + getEnrolDate() + "\n\t" +
        		"Last access: " + getLastAccess() + "\n\t";
        return outString;
    }
	/**
     * Prints user information to the console.
     */
	public void dump() { //Void? why not String?
		System.out.println(toString());
	}
	/**
     * Verifies if the provided ID is valid.
     *
     * @param id The ID to be verified.
     * @return true if the ID is valid, false otherwise.
     */
	
	public static boolean verifyId (long id) {
			
			if (String.valueOf(id).length() == ID_NUMBER_LENGHT) {
				return false;
			} else {
				return true ;
			}
		}
	/**
     * Checks if a given string is numeric.
     *
     * @param str The string to be checked.
     * @return true if the string is numeric, false otherwise.
     */
	public static boolean isNumeric(String str) { 
		  try {  
		    Double.parseDouble(str);  
		    return true;
		  } catch(NumberFormatException e){  
		    return false;  
		  }  
		}
		/**
     * Overrides the getTypeForDisplay method from the interface to provide the type of the student.
     * 
     * @return The type of the student.
     */
	//@Override
	public String getTypeForDisplay() {
		return "User";
	}
	
}
