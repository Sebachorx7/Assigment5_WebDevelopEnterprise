package inft2201.romeros;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
//import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Vector;

/**
 * This class provides methods to interact with a database related to Faculty.
 */
public class FacultyDA {
    /**
     * Contains references to Faculty objects.
     */
    static Vector<Faculty> Faculty = new Vector<Faculty>();	// contains Faculty references
    /**
     * The database connection object.
     */
    public static Connection aConnection;
    /**
     * The statement object for executing SQL queries.
     */
    static Statement aStatement;
    //private static Faculty aFaculty;
    private static long id;
    @SuppressWarnings("unused")
    private static String password, firstName, lastName, emailAddress, programCode, programDescription, schoolCode, schoolDescription, office;
    private static Date enrolDate, lastAccess;
    private static boolean enabled;
    private static char type;
    @SuppressWarnings("unused")
    private static int year, extension;

    //private static final SimpleDateFormat SQL_DF = new SimpleDateFormat("yyyy-MM-dd");
    /**
     * Initializes the connection to the database.
     *
     * @param c Database connection object.
     */
    public static void initialize(Connection c)
    {
            try {
                aConnection=c;
                aStatement=aConnection.createStatement();
            }
            catch (SQLException e)
            { System.out.println(e);	}
    }
    /**
     * Closes the connection to the database.
     */
    public static void terminate()
    {
            try
            { 	// close the statement
                aStatement.close();
            }
            catch (SQLException e)
            { System.out.println(e);	}
    }
    /**
     * Retrieves a Faculty from the database based on the provided ID.
     *
     * @param id ID of the Faculty to retrieve.
     * @return Faculty object representing the retrieved Faculty.
     * @throws NotFoundException If the Faculty is not found in the database.
     * @throws InvalidUserDataException  If the provided user data is invalid.
     */
    public static Faculty retrieve(long id) throws NotFoundException{
        // create a Faculty instance reference and set as null
        Faculty aFaculty = null;
    
        // create a SQL query to retrieve the User and Faculty data using INNER JOIN
        String userFacultyQuery = "SELECT U.Id, U.Password, U.FirstName, U.LastName, U.EmailAddress, U.LastAccess, U.EnrolDate, U.Enabled, U.Type, F.SchoolCode, F.SchoolDescription, F.Office, F.Extension " +
                                    "FROM Users U " +
                                    "INNER JOIN Faculty F ON U.Id = F.Id " +
                                    "WHERE U.Id = '" + id + "'";
    
        // execute the SQL query and get the result set
        try {
            // execute the SQL query User and Faculty and get the result set
            ResultSet rs = aStatement.executeQuery(userFacultyQuery);
            boolean success = rs.next();
            if (success) {
                // extract the data from the result set
                long userId = rs.getLong("Id");
                String password = rs.getString("Password");
                String firstName = rs.getString("FirstName");
                String lastName = rs.getString("LastName");
                String emailAddress = rs.getString("EmailAddress");
                Date lastAccess = rs.getDate("LastAccess");
                Date enrolDate = rs.getDate("EnrolDate");
                boolean enabled = rs.getBoolean("Enabled");
                char type = rs.getString("Type").charAt(0);
                String schoolCode = rs.getString("SchoolCode");
                String schoolDescription = rs.getString("SchoolDescription");
                String office = rs.getString("Office");
                int extension = rs.getInt("Extension");
    
                // Create the Faculty object
                aFaculty = new Faculty(userId, password, firstName, lastName, emailAddress, lastAccess, enrolDate, enabled, type, schoolCode, schoolDescription, office, extension);
            } else {
                // If no records found, throw NotFoundException
                throw new NotFoundException("Faculty with ID " + id + " not found.");
            }
        } catch (SQLException e) {
            throw new NotFoundException("Faculty with id " + id + " not found.");
        } catch (InvalidUserDataException e) {
            System.out.println(e);
        }
    
        return aFaculty;
    }
    /**
     * Creates a new Faculty in the database.
     *
     * @param aFaculty Faculty object representing the Faculty to create.
     * @return true if the creation was successful, false otherwise.
     * @throws DuplicateException If the Faculty already exists in the database.
     */
        public static boolean create(Faculty aFaculty) throws DuplicateException {
        boolean inserted = false; // insertion success flag
        // Extract Faculty attributes
        id = aFaculty.getId();
        password = aFaculty.getPassword();
        firstName = aFaculty.getFirstName();
        lastName = aFaculty.getLastName();
        emailAddress = aFaculty.getEmailAddress();
        lastAccess = aFaculty.getLastAccess();
        enrolDate = aFaculty.getEnrolDate();
        enabled = aFaculty.isEnabled();
        type = aFaculty.getType();
        schoolCode = aFaculty.getSchoolCode();
        schoolDescription = aFaculty.getSchoolDescription();
        office = aFaculty.getOffice();
        extension = aFaculty.getExtension();
        // Construct SQL insert statements
        String sqlInsertUser = "INSERT INTO users (id, password, firstName, lastName, emailAddress, lastAccess, enrolDate, enabled, Type) " +
                            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        String sqlInsertFaculty = "INSERT INTO faculty (id, schoolCode, schoolDescription, office, extension) " +
                                "VALUES (?, ?, ?, ?, ?)";

        try {
            // Check if the Faculty already exists in the database
            boolean FacultyExists = retrieve(id) != null;
            if (FacultyExists) {
                throw new DuplicateException("Faculty with ID " + id + " already exists in the database.");}
                
            // }else{
            //     throw new NotFoundException("Faculty with id " + id + " not found.");
            // }
            // Prepare and execute SQL insert statements
            PreparedStatement pstmtUser = aConnection.prepareStatement(sqlInsertUser);
            pstmtUser.setLong(1, id);
            pstmtUser.setString(2, password);
            pstmtUser.setString(3, firstName);
            pstmtUser.setString(4, lastName);
            pstmtUser.setString(5, emailAddress);
            pstmtUser.setDate(6, new java.sql.Date(lastAccess.getTime()));
            pstmtUser.setDate(7, new java.sql.Date(enrolDate.getTime()));
            pstmtUser.setBoolean(8, enabled);
            pstmtUser.setString(9, String.valueOf(type));
            int rowsAffectedUser = pstmtUser.executeUpdate();

            PreparedStatement pstmtFaculty = aConnection.prepareStatement(sqlInsertFaculty);
            pstmtFaculty.setLong(1, id);
            pstmtFaculty.setString(2, schoolCode);
            pstmtFaculty.setString(3, schoolDescription);
            pstmtFaculty.setString(4, office);
            pstmtFaculty.setInt(5, extension);
            int rowsAffectedFaculty = pstmtFaculty.executeUpdate();

            // Check if insertion was successful
            if (rowsAffectedUser > 0 && rowsAffectedFaculty > 0) {
                inserted = true;
            } else {
                inserted = false;
            }

            pstmtUser.close();
            pstmtFaculty.close();
        } catch (NotFoundException e) {
            System.out.println(e.getMessage());
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

        return inserted;
    }
    /**
     * Updates the information of a Faculty in the database.
     *
     * @param aFaculty Faculty object representing the Faculty to update.
     * @return Number of records updated in the database.
     */
    public static int update(Faculty aFaculty) {
        int records = 0; // Records updated in method
        try {
            // Retrieve the Faculty attribute values
            long id = aFaculty.getId();
            String password = aFaculty.getPassword();
            String firstName = aFaculty.getFirstName();
            String lastName = aFaculty.getLastName();
            String emailAddress = aFaculty.getEmailAddress();
            Date lastAccess = aFaculty.getLastAccess();
            Date enrolDate = aFaculty.getEnrolDate();
            boolean enabled = aFaculty.isEnabled();
            char type = aFaculty.getType();
            String schoolCode = aFaculty.getSchoolCode();
            String schoolDescription = aFaculty.getSchoolDescription();
            String office = aFaculty.getOffice();
            int extension = aFaculty.getExtension();
    
            // Construct SQL update statements
            String sqlUpdateUser = "UPDATE Users " +
                                    "SET Password = ?, " +
                                    "FirstName = ?, " +
                                    "LastName = ?, " +
                                    "EmailAddress = ?, " +
                                    "LastAccess = ?, " +
                                    "EnrolDate = ?, " +
                                    "Enabled = ?, " +
                                    "Type = ? " +
                                    "WHERE Id = ?";
            String sqlUpdateFaculty = "UPDATE Faculty " +
                                        "SET SchoolCode = ?, " +
                                        "SchoolDescription = ?, " +
                                        "Office = ?, " +
                                        "Extension = ? " +
                                        "WHERE Id = ?";
    
            // Prepare and execute SQL update statements
            PreparedStatement pstmtUser = aConnection.prepareStatement(sqlUpdateUser);
            pstmtUser.setString(1, password);
            pstmtUser.setString(2, firstName);
            pstmtUser.setString(3, lastName);
            pstmtUser.setString(4, emailAddress);
            pstmtUser.setDate(5, new java.sql.Date(lastAccess.getTime()));
            pstmtUser.setDate(6, new java.sql.Date(enrolDate.getTime()));
            pstmtUser.setBoolean(7, enabled);
            pstmtUser.setString(8, String.valueOf(type));
            pstmtUser.setLong(9, id);
            records += pstmtUser.executeUpdate();
    
            PreparedStatement pstmtFaculty = aConnection.prepareStatement(sqlUpdateFaculty);
            pstmtFaculty.setString(1, schoolCode);
            pstmtFaculty.setString(2, schoolDescription);
            pstmtFaculty.setString(3, office);
            pstmtFaculty.setInt(4, extension);
            records += pstmtFaculty.executeUpdate();
    
            pstmtUser.close();
            pstmtFaculty.close();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    
        return records;
    }
    
    /**
     * Deletes a Faculty from the database.
     *
     * @param aFaculty Faculty object representing the Faculty to delete.
     * @return Number of records deleted in the database.
     */
    public static int delete(Faculty aFaculty) {
        int records = 0; // Records deleted in method
    
        try {
            // Retrieve the Faculty attribute values
            long id = aFaculty.getId();
    
            // Construct SQL delete statements
            String sqlDeleteUser = "DELETE FROM Users WHERE Id = ?";
            String sqlDeleteFaculty = "DELETE FROM Faculty WHERE Id = ?";
    
            // Prepare and execute SQL delete statements
            PreparedStatement pstmtUser = aConnection.prepareStatement(sqlDeleteUser);
            pstmtUser.setLong(1, id);
            records += pstmtUser.executeUpdate();
    
            PreparedStatement pstmtFaculty = aConnection.prepareStatement(sqlDeleteFaculty);
            pstmtFaculty.setLong(1, id);
            records += pstmtFaculty.executeUpdate();
    
            pstmtUser.close();
            pstmtFaculty.close();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return records;
    }
    
}
    
