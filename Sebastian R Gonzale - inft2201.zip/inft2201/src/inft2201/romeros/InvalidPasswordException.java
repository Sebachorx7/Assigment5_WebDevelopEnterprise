package inft2201.romeros;
@SuppressWarnings("serial")
/**
 * Represents an exception thrown when an invalid password is encountered.
 */
public class InvalidPasswordException extends Exception {
	// Default constructor
    /**
     * Default constructor for InvalidPasswordException.
     * Constructs an exception with a default error message.
     */
	public InvalidPasswordException() {
		super("Your password must be at least " + User.MINIMUM_PASSWORD_LENGTH + " characters long and no more than " + User.MAXIMUM_PASSWORD_LENGTH + " characters long.");
	}
	//Parameterized constructor
	/**
     * Parameterized constructor for InvalidPasswordException.
     * Constructs an exception with a custom error message.
     *
     * @param message The custom error message.
     */
	 public InvalidPasswordException(String message) {
	     super(message);
	 }
}
