package inft2201.romeros;
import java.sql.Connection;
import java.util.Vector;
import java.util.Date;

/**
 * This class represents a student with specific properties and behaviors.
 */
public class Student extends User{
	/**
     * Initializes the connection to the database for student operations.
     *
     * @param c The database connection object.
     */
	
    public static void initialize(Connection c) {
        StudentDA.initialize(c);
    }
	/**
     * Terminates the connection to the database.
     */
    public static void terminate() {
        StudentDA.terminate();
    }

    /**
     * Authenticates a student with the provided ID and password.
     *
     * @param id       the ID of the student
     * @param password the password of the student
     * @return the authenticated student if found
     * @throws NotFoundException if the student is not found
     */
    public static Student authenticate(long id, String password) throws NotFoundException {
        // Delegates the authentication process to the StudentDA class
        return StudentDA.authenticate(id, password);
    }
	/**
     * Retrieves a student from the database based on the provided ID.
     *
     * @param id The ID of the student to retrieve.
     * @return A Student object representing the retrieved student.
     * @throws NotFoundException If the student is not found in the database.
     */
    public static Student retrieve(long id) throws NotFoundException {
        return StudentDA.retrieve(id);
    }
	/**
     * Creates a new student in the database using the current object's data.
     *
     * @throws DuplicateException If the student already exists in the database.
     */
    public void create() throws DuplicateException {
        StudentDA.create(this);
    }
	/**
     * Updates the existing student's information in the database using the current object's data.
     *
     * @throws NotFoundException If the student is not found in the database.
     */
    public void update() throws NotFoundException {
        StudentDA.update(this);
    }
	/**
     * Deletes the current student from the database.
     *
     * @throws NotFoundException If the student is not found in the database.
     */
    public void delete() throws NotFoundException {
        StudentDA.delete(this);
    }
	//Properties - Class Attributes.
	/**
     * Default program code for undeclared programs.
     */
	public static final String DEFAULT_PROGRAM_CODE = "UNDC";
	/**
     * Default program description for undeclared programs.
     */
	public static final String DEFAULT_PROGRAM_DESCRIPTION = "Undeclared";
	/**
     * Default academic year for undeclared programs.
     */
	public static final int DEFAULT_YEAR = 1;
	
	// Instance Attributes
	/**
     * The program code for the student's academic program.
     */
	private String programCode;
	/**
     * The program description for the student's academic program.
     */
	private String programDescription;
	/**
     * The academic year of the student in the program.
     */
	private int year;
	/**
     * Vector holding marks related to the program.
     */
	private Vector<?> marks;
	
	// Accessors - Mutators
	/**
     * Gets the program code of the student.
     *
     * @return the programCode
     */
	public String getProgramCode() {
		return programCode;
	}
	/**
     * Sets the program code for the student.
     *
     * @param programCode the programCode to set
     */
	public void setProgramCode(String programCode) {
		this.programCode = programCode;
	}
	 /**
     * Gets the program description of the student.
     *
     * @return the programDescription
     */
	public String getProgramDescription() {
		return programDescription;
	}
	/**
     * Sets the program description for the student.
     *
     * @param programDescription the programDescription to set
     */
	public void setProgramDescription(String programDescription) {
		this.programDescription = programDescription;
	}
	/**
     * Gets the year of study for the student.
     *
     * @return the year
     */
	public int getYear() {
		return year;
	}
	/**
     * Sets the year of study for the student.
     *
     * @param year the year to set
     */
	public void setYear(int year) {
		this.year = year;
	}
	/**
     * Gets the vector of marks for the student.
     *
     * @return the marks
     */
	public Vector<?> getMarks() {
		return marks;
	}
	/**
     * Sets the vector of marks for the student.
     *
     * @param marks the marks to set
     */
	public void setMarks(Vector<?> marks) {
		this.marks = marks;
	}
	
	// Parameterized Constructor.
	/**
     * Parameterized constructor for creating a Student object with specific attributes.
     * 
     * @param programCode       The program code of the student.
     * @param programDescription The program description of the student.
     * @param year              The year of study for the student.
     * @param id                The ID of the student.
     * @param password          The password of the student.
     * @param firstName         The first name of the student.
     * @param lastName          The last name of the student.
     * @param emailAddress      The email address of the student.
     * @param lastAcess        The last access date of the student.
     * @param enrolDate         The enrollment date of the student.
     * @param enabled           The enabled status of the student.
     * @param type              The type of the student.
     * @throws InvalidUserDataException If the provided user data is invalid.
     */
	public Student(
			long id, 
			String password,
			String firstName, 
			String lastName, 
			String emailAddress,
			Date lastAcess,
			Date enrolDate,
			boolean enabled,
			char type,
			String programCode,
			String programDescription,
			int year
			
			) throws InvalidUserDataException {
		super(
				id, 
				password, 
				firstName, 
				lastName, 
				emailAddress,
				lastAcess,
				enrolDate,
				enabled,
				type
				);
		setProgramCode(programCode);
		setProgramDescription(programDescription);
		setYear(year);
		this.marks = new Vector<>();
	}
	// Overloaded Constructor.
	/**
     * Overloaded constructor for creating a Student object with additional marks vector.
     * 
     * @param programCode       The program code of the student.
     * @param programDescription The program description of the student.
     * @param year              The year of study for the student.
     * @param id                The ID of the student.
     * @param password          The password of the student.
     * @param firstName         The first name of the student.
     * @param lastName          The last name of the student.
     * @param emailAddress      The email address of the student.
     * @param lastAccess        The last access date of the student.
     * @param enrolDate         The enrollment date of the student.
     * @param enabled           The enabled status of the student.
     * @param type              The type of the student.
     * @param marks             The vector of marks for the student.
     * @throws InvalidUserDataException If the provided user data is invalid.
     */
	public Student(
			String programCode, 
			String programDescription, 
			int year, 
			long id, 
			String password, 
			String firstName, 
			String lastName, 
			String emailAddress,
            Date lastAccess, 
            Date enrolDate, 
            boolean enabled, 
            char type,
            Vector<Mark> marks
            ) throws InvalidUserDataException {
		this(
				id, 
				password, 
				firstName, 
				lastName,
				emailAddress, 
				lastAccess,
				enrolDate, 
				enabled, 
				type, 
				programCode, 
				programDescription, 
				year
			
			);
		this.marks = marks;
}
	// Default Constructor.
	/**
     * Default constructor for creating a Student object with default attributes.
     * 
     * @throws InvalidUserDataException If the provided user data is invalid.
     */
	public Student() throws InvalidUserDataException {
		this(DEFAULT_ID, DEFAULT_PASSWORD, DEFAULT_FIRST_NAME, DEFAULT_LAST_NAME,
                DEFAULT_EMAIL_ADDRESS, new Date(), new Date(), DEFAULT_ENABLED_STATUS, DEFAULT_TYPE, DEFAULT_PROGRAM_CODE, DEFAULT_PROGRAM_DESCRIPTION, DEFAULT_YEAR);
		this.marks = new Vector<>();
	}
	
	// Methods.
	/**
     * Overrides the toString method to provide a formatted string representation of the student.
     * 
     * @return Formatted string containing student information.
     */
	@Override
	public String toString() {
	      String outString = "Student Info for:\n" +
	              "\t" + getFirstName() + " " + getLastName() + " (" + getId() + ")\n" +
	              "\tCurrently in " + getYearSuffix() + " year of \"" + getProgramDescription() + "\" (" + getProgramCode() + ")\n" +
	              "\tEnrolled: " + getEnrolDate();
	      //CollegeInterface.DF.format(getEnrolDate());
	      return outString;
	}
//	Student Info for:
//		John Doe (100123456)
//		Currently in 1st year of "Undeclared" (UNDC)
//		Enrolled: 23-Jan-2017
	/**
     * Overrides the getTypeForDisplay method from the interface to provide the type of the student.
     * 
     * @return The type of the student.
     */
	//@Override
	public String getTypeForDisplay() {
		return "Student";
	}
	/**
     * Helper method to determine the suffix for the year.
     * 
     * @return The suffix for the year (e.g., "1st", "2nd", "3rd", "th").
     */
	// Helper method to determine the suffix for the year
	  private String getYearSuffix() {
	      if (year == 1) {
	          return year + "st";
	      } else if (year == 2) {
	          return year + "nd";
	      } else if (year == 3) {
	          return year + "rd";
	      } else {
	          return year + "th";
	      }
	  }

}


