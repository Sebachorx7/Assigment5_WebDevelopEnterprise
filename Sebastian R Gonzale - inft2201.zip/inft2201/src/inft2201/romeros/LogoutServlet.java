package inft2201.romeros;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

/**
 * Servlet implementation class LogoutServlet
 * This servlet handles the logout functionality.
 */
public class LogoutServlet extends HttpServlet {

    /**
     * Handles the HTTP GET request.
     * @param request  the HttpServletRequest object
     * @param response the HttpServletResponse object
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException      if an I/O error occurs
     */
    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Get the session object
        HttpSession session = request.getSession();

        // Set a logout message in the session
        session.setAttribute("logoutMessage", "You have successfully logged out.");

        // Remove the "student" attribute from the session
        session.invalidate();

        // Redirect the user to the login page
        response.sendRedirect("./login.jsp");
    }
}
                
