package inft2201.romeros;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet for deleting a user.
 */
public class DeleteServlet extends HttpServlet {
    
    /**
     * Handles HTTP POST requests.
     *
     * @param request  the HTTP request
     * @param response the HTTP response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException      if an I/O error occurs
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Get the ID of the user to be deleted from the request parameter
        String idString = request.getParameter("userId");
        System.out.println("Deleted user ID: " + idString);
        long id = Long.parseLong(idString);
        
        // Initialize the connection
        Connection connection = null;
        try {
            connection = DatabaseConnect.initialize();

            // Delete the user from the "students" table first
            deleteUserFromStudentsTable(id, connection);
            // Delete the user from the "faculty" table
            deleteUserFromFacultyTable(id, connection);
            // Then, delete the user from the "users" table
            deleteUserFromUsersTable(id, connection);
            
            // Show a success deletion message
            request.setAttribute("deletedMessage", "User deleted successfully.");
            // Forward the request to the original servlet or JSP page to display the message
            request.getRequestDispatcher("admin.jsp").forward(request, response);
        } catch (SQLException e) {
            e.printStackTrace();
            // Error handling
            // Show an error message
            request.setAttribute("errorMessage", "An error occurred while deleting the user.");
            // Forward the request to the original servlet or JSP page to display the error message
            request.getRequestDispatcher("admin.jsp").forward(request, response);
        } finally {
            // Close the connection
            try {
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * Deletes the user from the "users" table.
     *
     * @param id         the ID of the user to delete
     * @param connection the database connection
     * @throws SQLException if a database access error occurs
     */
    private void deleteUserFromUsersTable(long id, Connection connection) throws SQLException {
        // Prepare the SQL statement to delete the user from the "users" table
        PreparedStatement statement = connection.prepareStatement("DELETE FROM users WHERE Id = ?");
        statement.setLong(1, id);
        // Execute the deletion
        statement.executeUpdate();
    }

    /**
     * Deletes the user from the "students" table.
     *
     * @param id         the ID of the user to delete
     * @param connection the database connection
     * @throws SQLException if a database access error occurs
     */
    private void deleteUserFromStudentsTable(long id, Connection connection) throws SQLException {
        // Prepare the SQL statement to delete the user from the "students" table
        PreparedStatement statement = connection.prepareStatement("DELETE FROM students WHERE Id = ?");
        statement.setLong(1, id);
        // Execute the deletion
        statement.executeUpdate();
    }

    /**
     * Deletes the user from the "faculty" table.
     *
     * @param id         the ID of the user to delete
     * @param connection the database connection
     * @throws SQLException if a database access error occurs
     */
    private void deleteUserFromFacultyTable(long id, Connection connection) throws SQLException {
        // Prepare the SQL statement to delete the user from the "faculty" table
        PreparedStatement statement = connection.prepareStatement("DELETE FROM faculty WHERE Id = ?");
        statement.setLong(1, id);
        // Execute the deletion
        statement.executeUpdate();
    }
}
