package inft2201.romeros;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;

/**
 * This class represents a Data Access Object (DAO) for managing User data.
 */
public class UserDA {

    /**
     * Connection object to interact with the database.
     */
    public static Connection aConnection;

    /**
     * Statement object for executing SQL queries.
     */
    static Statement aStatement;

    /**
     * User ID.
     */
    private static long id;

    /**
     * User password.
     */
    @SuppressWarnings("unused")
    private static String password;

    /**
     * User first name.
     */
    private static String firstName;

    /**
     * User last name.
     */
    private static String lastName;

    /**
     * User email address.
     */
    private static String emailAddress;

    /**
     * Date when the user enrolled.
     */
    private static Date enrolDate;

    /**
     * Date of the user's last access.
     */
    private static Date lastAccess;

    /**
     * Flag indicating whether the user account is enabled.
     */
    private static boolean enabled;

    /**
     * Type of the user.
     */
    private static char type;

    /**
     * Initializes the User Data Access Object with the provided database connection.
     * 
     * @param c The database connection.
     */
    public static void initialize(Connection c) {
        try {
            aConnection = c;
            aStatement = aConnection.createStatement();
        } catch (SQLException e) {
            System.out.println(e);
        }
    }

    /**
     * Closes the connection to the database.
     */
    public static void terminate() {
        try {
            aStatement.close();
        } catch (SQLException e) {
            System.out.println(e);
        }
    }

    /**
     * Retrieves a user from the database based on the provided ID.
     * 
     * @param id The ID of the user to retrieve.
     * @return The User object if found, otherwise null.
     * @throws NotFoundException If the user with the specified ID is not found.
     */
    public static User retrieve(long id) throws NotFoundException {
        User aUser = null;

        String userQuery = "SELECT Id, Password, FirstName, LastName, EmailAddress, LastAccess, EnrolDate, Enabled, Type " +
        "FROM Users " +
        "WHERE Id = ?"; // Using '?' as a placeholder for the parameter



        try {
            PreparedStatement preparedStatement = aConnection.prepareStatement(userQuery);
            preparedStatement.setLong(1, id); // Setting the value of the parameter
            ResultSet rs = preparedStatement.executeQuery();
            boolean success = rs.next();
            if (success) {
                long userId = rs.getLong("Id");
                String password = rs.getString("Password");
                String firstName = rs.getString("FirstName");
                String lastName = rs.getString("LastName");
                String emailAddress = rs.getString("EmailAddress");
                Date lastAccess = rs.getDate("LastAccess");
                Date enrolDate = rs.getDate("EnrolDate");
                boolean enabled = rs.getBoolean("Enabled");
                char type = rs.getString("Type").charAt(0);

                aUser = new User(userId, password, firstName, lastName, emailAddress, lastAccess, enrolDate, enabled, type);
            } else {
                throw new NotFoundException("User with ID " + id + " not found.");
            }
        } catch (SQLException e) {
            throw new NotFoundException("User with ID " + id + " not found.");
        
	    } catch (InvalidUserDataException e) {
	        System.out.println(e);
	    }

        return aUser;
    }
    /**
     * Creates a new user in the database.
     *
     * @param aUser The user object to be created.
     * @return True if the user was successfully created, false otherwise.
     * @throws DuplicateException If a user with the same ID already exists in the database.
     */
    public static boolean create(User aUser) throws DuplicateException {
        boolean inserted = false; // Flag indicating successful insertion
        PreparedStatement pstmtUser = null;

        // Extract user attributes
        long id = aUser.getId();
        String password = aUser.getPassword();
        String firstName = aUser.getFirstName();
        String lastName = aUser.getLastName();
        String emailAddress = aUser.getEmailAddress();
        Date lastAccess = aUser.getLastAccess();
        Date enrolDate = aUser.getEnrolDate();
        boolean enabled = aUser.isEnabled();
        char type = aUser.getType();

        // Construct SQL insert statement for users
        String sqlInsertUser = "INSERT INTO users (id, password, firstName, lastName, emailAddress, lastAccess, enrolDate, enabled, Type) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        // SQL query to check if user exists
        String sqlCheckUser = "SELECT id FROM users WHERE id = ?";
        PreparedStatement pstmtCheckUser = null;
        ResultSet rs = null;

        try {
            // Check if the user already exists in the database
            pstmtCheckUser = aConnection.prepareStatement(sqlCheckUser);
            pstmtCheckUser.setLong(1, id);
            rs = pstmtCheckUser.executeQuery();
            if (rs.next()) {
                throw new DuplicateException("User with ID " + id + " already exists in the database.");
            }

            // Prepare SQL statement
            pstmtUser = aConnection.prepareStatement(sqlInsertUser);
            pstmtUser.setLong(1, id);
            pstmtUser.setString(2, password);
            pstmtUser.setString(3, firstName);
            pstmtUser.setString(4, lastName);
            pstmtUser.setString(5, emailAddress);
            pstmtUser.setDate(6, new java.sql.Date(lastAccess.getTime()));
            pstmtUser.setDate(7, new java.sql.Date(enrolDate.getTime()));
            pstmtUser.setBoolean(8, enabled);
            pstmtUser.setString(9, String.valueOf(type));

            // Execute the insertion
            int rowsAffectedUser = pstmtUser.executeUpdate();

            // Check if the insertion was successful
            if (rowsAffectedUser > 0) {
                inserted = true;
            } else {
                inserted = false;
            }
        } catch (SQLException e) {
            // Handle the exception
            e.printStackTrace();
            inserted = false;
        } finally {
            // Close resources
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pstmtCheckUser != null) {
                    pstmtCheckUser.close();
                }
                if (pstmtUser != null) {
                    pstmtUser.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return inserted;
    }
    /**
     * Updates the information of a User in the database.
     *
     * @param aUser User object representing the User to update.
     * @return Number of records updated in the database.
     */
    public static int update(User aUser) {
        int records = 0; // Records updated in method
        try {
            // Retrieve the User attribute values
            long id = aUser.getId();
            String password = aUser.getPassword();
            String firstName = aUser.getFirstName();
            String lastName = aUser.getLastName();
            String emailAddress = aUser.getEmailAddress();
            Date lastAccess = aUser.getLastAccess();
            Date enrolDate = aUser.getEnrolDate();
            boolean enabled = aUser.isEnabled();
            char type = aUser.getType();

            // Construct SQL update statements
            String sqlUpdateUser = "UPDATE Users " +
                                    "SET Password = ?, " +
                                    "FirstName = ?, " +
                                    "LastName = ?, " +
                                    "EmailAddress = ?, " +
                                    "LastAccess = ?, " +
                                    "EnrolDate = ?, " +
                                    "Enabled = ?, " +
                                    "Type = ? " +
                                    "WHERE Id = ?";

            // Prepare and execute SQL update statements
            PreparedStatement pstmtUser = aConnection.prepareStatement(sqlUpdateUser);
            pstmtUser.setString(1, password);
            pstmtUser.setString(2, firstName);
            pstmtUser.setString(3, lastName);
            pstmtUser.setString(4, emailAddress);
            pstmtUser.setDate(5, new java.sql.Date(lastAccess.getTime()));
            pstmtUser.setDate(6, new java.sql.Date(enrolDate.getTime()));
            pstmtUser.setBoolean(7, enabled);
            pstmtUser.setString(8, String.valueOf(type));
            pstmtUser.setLong(9, id);
            records += pstmtUser.executeUpdate();

            // pstmtUser.close();
            pstmtUser.close();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    
        return records;
    }
    
    /**
     * Deletes a User from the database.
     *
     * @param aUser User object representing the User to delete.
     * @return Number of records deleted in the database.
     */
    public static int delete(User aUser) {
        int records = 0; // Records deleted in method
    
        try {
            // Retrieve the User attribute values
            long id = aUser.getId();
    
            // Construct SQL delete statements
            String sqlDeleteUser = "DELETE FROM Users WHERE Id = ?";
            // String sqlDeleteUser = "DELETE FROM User WHERE Id = ?";
    
            // Prepare and execute SQL delete statements
            PreparedStatement pstmtUser = aConnection.prepareStatement(sqlDeleteUser);
            pstmtUser.setLong(1, id);
            records += pstmtUser.executeUpdate();
    
            pstmtUser.close();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return records;
    }
}
