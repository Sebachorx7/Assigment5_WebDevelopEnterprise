package inft2201.romeros;

import java.sql.Connection;
import java.util.Date;

/**
 * Represents a Faculty user with specific attributes related to their role.
 */
public class Faculty extends User{
	
	/**
     * Initializes the connection to the database for faculty operations.
     *
     * @param c The database connection object.
     */
    public static void initialize(Connection c) {
        FacultyDA.initialize(c);
    }
	/**
     * Terminates the connection to the database.
     */
    public static void terminate() {
        FacultyDA.terminate();
    }
	/**
     * Retrieves a faculty from the database based on the provided ID.
     *
     * @param id The ID of the faculty to retrieve.
     * @return A faculty object representing the retrieved faculty.
     * @throws NotFoundException If the faculty is not found in the database.
     */
    public static Faculty retrieve(long id) throws NotFoundException {
        return FacultyDA.retrieve(id);
    }
	/**
     * Creates a new faculty in the database using the current object's data.
     *
     * @throws DuplicateException If the faculty already exists in the database.
     */
    public void create() throws DuplicateException {
        FacultyDA.create(this);
    }
	/**
     * Updates the existing faculty's information in the database using the current object's data.
     *
     * @throws NotFoundException If the faculty is not found in the database.
     */
    public void update() throws NotFoundException {
        FacultyDA.update(this);
    }
	/**
     * Deletes the current faculty from the database.
     *
     * @throws NotFoundException If the faculty is not found in the database.
     */
    public void delete() throws NotFoundException {
        FacultyDA.delete(this);
    }
	//Properties - Class Attributes.
	/**
     * Default school code for a faculty member.
     */
	public static final String DEFAULT_SCHOOL_CODE = "SET";
	/**
     * Default school description for a faculty member.
     */
	public static final String DEFAULT_SCHOOL_DESCRIPTION = "School of Engineering & Technology";
	 /**
     * Default office location for a faculty member.
     */
	public static final String DEFAULT_OFFICE = "H-140";
	/**
     * Default phone extension for a faculty member.
     */
	public static final int DEFAULT_PHONE_EXTENSION = 1234;
	
	// Instance Attributes
	private String schoolCode;
	private String schoolDescription;
	private String office;
	private int extension;
	
	// Accessors - Mutators
	/**
     * Gets the school code of the faculty.
     *
     * @return the schoolCode
     */
	public String getSchoolCode() {
		return schoolCode;
	}
	/**
     * Sets the school code of the faculty.
     *
     * @param schoolCode the schoolCode to set
     */
	public void setSchoolCode(String schoolCode) {
		this.schoolCode = schoolCode;
	}
	/**
     * Gets the school description of the faculty.
     *
     * @return the schoolDescription
     */
	public String getSchoolDescription() {
		return schoolDescription;
	}
	/**
     * Sets the school description of the faculty.
     *
     * @param schoolDescription the schoolDescription to set
     */
	public void setSchoolDescription(String schoolDescription) {
		this.schoolDescription = schoolDescription;
	}
	/**
     * Gets the office location of the faculty.
     *
     * @return the office
     */
	public String getOffice() {
		return office;
	}
	/**
     * Sets the office location of the faculty.
     *
     * @param office the office to set
     */
	public void setOffice(String office) {
		this.office = office;
	}
	/**
     * Gets the phone extension of the faculty.
     *
     * @return the extension
     */
	public int getExtension() {
		return extension;
	}
	/**
     * Sets the phone extension of the faculty.
     *
     * @param extension the extension to set
     */
	public void setExtension(int extension) {
		this.extension = extension;
	}
	
	// Parameterized Constructor.
	/**
     * Constructs a Faculty object with specified attributes, inheriting from the User class.
     *
     * @param schoolCode       The school code of the faculty.
     * @param schoolDescription The school description of the faculty.
     * @param office            The office location of the faculty.
     * @param extension         The phone extension of the faculty.
     * @param id                The ID of the faculty.
     * @param password          The password of the faculty.
     * @param firstName         The first name of the faculty.
     * @param lastName          The last name of the faculty.
     * @param emailAddress      The email address of the faculty.
     * @param lastAcess         The last access date of the faculty.
     * @param enrolDate         The enrollment date of the faculty.
     * @param enabled           The enabled status of the faculty.
     * @param type              The type of the faculty.
     * @throws InvalidUserDataException If the provided user data is invalid.
     */
	public Faculty(
			long id, 
			String password,
			String firstName, 
			String lastName, 
			String emailAddress,
			Date lastAcess,
			Date enrolDate,
			boolean enabled,
			char type,
			String schoolCode,
			String schoolDescription,
			String office,
			int extension
			
			) throws InvalidUserDataException {
		// Superclass.
		super(
				id, 
				password, 
				firstName, 
				lastName, 
				emailAddress,
				lastAcess,
				enrolDate,
				enabled,
				type
				);
		 setSchoolCode(schoolCode);
		 setSchoolDescription(schoolDescription);
		 setOffice(office);
		 setExtension(extension);
//		// Values for instance attributes.
//		this.schoolCode = schoolCode;
//		this.schoolDescription = schoolDescription;
//		this.office = office;
//		this.extension = extension;
		
	}
	// Default Constructor.
	/**
	 * Constructs a new Faculty object with default values.
	 * 
	 * @throws InvalidUserDataException If an invalid user data is encountered during construction.
	 * @throws InvalidIdException      If an invalid ID is encountered during construction.
	 */
	public Faculty() throws InvalidUserDataException, InvalidIdException {
        
		super();
        
        setSchoolCode(DEFAULT_SCHOOL_CODE);
        setSchoolDescription(DEFAULT_SCHOOL_DESCRIPTION);
        setOffice(DEFAULT_OFFICE);
        setExtension(DEFAULT_PHONE_EXTENSION);
    }
	/**
	 * Overrides the getTypeForDisplay method to return the display type for a Faculty user.
	 *
	 * @return A string representing the display type, which is "Faculty".
	 */
	@Override
	public String getTypeForDisplay() {
        return "Faculty";
    }
	
	// Override Method.
	/**
     * Overrides the toString method to provide formatted faculty information.
     *
     * @return Formatted string containing faculty information.
     */
	@Override
	public String toString() {
		String outString = super.toString();
		outString = outString.replaceAll("User", getTypeForDisplay());
		outString += "\n\t" +
                getSchoolDescription() + " (" + getSchoolCode() + ")\n\t" +
                "Office: " + getOffice() + "\n\t" +
                CollegeInterface.PHONE_NUMBER + " x" + getExtension();
		return outString;
    }
}