package inft2201.romeros;
@SuppressWarnings("serial")
/**
 * Custom exception class for handling invalid user data.
 */
public class InvalidUserDataException extends Exception {
	/**
     * Constructs an InvalidUserDataException with a custom error message.
     *
     * @param message The custom error message.
     */
    public InvalidUserDataException() {
		super();
	}
    /**
     * Constructs an InvalidUserDataException with a custom error message and cause.
     *
     * @param message The custom error message.
     * @param cause   The cause of the exception.
     */
	public InvalidUserDataException(String message, Throwable cause) {
        super(message, cause);
    }
}