package inft2201.romeros;
@SuppressWarnings("serial")
/**
 * The DuplicateException class represents an exception thrown when attempting
 * to create a duplicate entry in the system.
 */
public class DuplicateException extends Exception {
    /**
     * Default constructor for DuplicateException.
     */
    public DuplicateException() {
        super();
    }
    /**
     * Constructor for DuplicateException with a custom message.
     *
     * @param message A description of the exception.
     */
    public DuplicateException(String message) {
        super(message);
    }
}