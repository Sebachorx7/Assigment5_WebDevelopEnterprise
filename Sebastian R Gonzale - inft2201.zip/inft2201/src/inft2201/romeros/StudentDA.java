package inft2201.romeros;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
//import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Vector;

/**
 * This class provides methods to interact with a database related to students.
 */
public class StudentDA {
    /**
     * Contains references to student objects.
     */
	static Vector<Student> student = new Vector<Student>();	// contains student references
    /**
     * The database connection object.
     */
    public static Connection aConnection;
    /**
     * The statement object for executing SQL queries.
     */
    static Statement aStatement;
    //private static Student aStudent;
    private static long id;
    @SuppressWarnings("unused")
    private static String password, firstName, lastName, emailAddress, programCode, programDescription, schoolCode, schoolDescription, office;
    private static Date enrolDate, lastAccess;
    private static boolean enabled;
    private static char type;
    @SuppressWarnings("unused")
    private static int year, extension;
    private static final SimpleDateFormat SQL_DF = new SimpleDateFormat("yyyy-MM-dd");
   
    //private static final SimpleDateFormat SQL_DF = new SimpleDateFormat("yyyy-MM-dd");
    /**
     * Initializes the connection to the database.
     *
     * @param c Database connection object.
     */
	public static void initialize(Connection c)
	{
            try {
                aConnection=c;
                aStatement=aConnection.createStatement();
            }
            catch (SQLException e)
            { System.out.println(e);	}
	}
    /**
     * Closes the connection to the database.
     */
	public static void terminate()
	{
            try
            { 	// close the statement
                aStatement.close();
            }
            catch (SQLException e)
            { System.out.println(e);	}
	}

    /**
     * Generates a hashed password using the SHA-1 hashing algorithm.
     *
     * @param passwordToHash The password to be hashed.
     * @return The hashed password.
     */

    public static String hashPassword(String passwordToHash){
        //String passwordToHash = "password";
        String generatedPassword = null;

            try 
            {
            // Create MessageDigest instance for MD5
            MessageDigest md = MessageDigest.getInstance("sha-1");
            
            md.update(passwordToHash.getBytes());

            // Get the hash's bytes
            byte[] bytes = md.digest();

            // This bytes[] has bytes in decimal format. Convert it to hexadecimal format
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < bytes.length; i++) {
                sb.append(Integer.toString((bytes[i] & 0xff) + 0x100, 16).substring(1));
            }

            // Get complete hashed password in hex format
            generatedPassword = sb.toString();
            } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            }
            return generatedPassword;
    }
    /**
     * Retrieves a student from the database based on the provided ID.
     *
     * @param id ID of the student to retrieve.
     * @return Student object representing the retrieved student.
     * @throws NotFoundException If the student is not found in the database.
     */
    
    public static Student retrieve(long id) throws NotFoundException {
        Student aStudent = null;
        
        try {
            // Retrieve the user using UserDA method, avoiding redundance.
            User aUser = UserDA.retrieve(id);
    
            // If the user is found, extract the common attributes
            if (aUser != null) {
                String programCode = null;
                String programDescription = null;
                int year = 0;
    
                // Query the Students table to get the student-specific attributes
                final String sqlQueryStudents = "SELECT programCode, programDescription, year FROM students WHERE id = ?";
                PreparedStatement pstmtStudents = aConnection.prepareStatement(sqlQueryStudents);
                pstmtStudents.setLong(1, id);
                ResultSet rsStudents = pstmtStudents.executeQuery();
    
                // If student data is found, extract it
                if (rsStudents.next()) {
                    programCode = rsStudents.getString("programCode");
                    programDescription = rsStudents.getString("programDescription");
                    year = rsStudents.getInt("year");
                }
    
                // Create the Student object
                aStudent = new Student(aUser.getId(), aUser.getPassword(), aUser.getFirstName(), aUser.getLastName(),
                        aUser.getEmailAddress(), aUser.getLastAccess(), aUser.getEnrolDate(), aUser.isEnabled(),
                        aUser.getType(), programCode, programDescription, year);
            } else {
                throw new NotFoundException("Student with ID " + id + " not found.");
            }
        } catch (SQLException | NotFoundException |InvalidUserDataException e) {
            System.out.println(e);
        }
        
        return aStudent;
    }
    /**
     * Authenticates a student with the provided ID and password.
     *
     * @param id       the ID of the student
     * @param password the password of the student
     * @return the authenticated student if found, otherwise null
     * @throws NotFoundException if the student is not found
     */
    public static Student authenticate(long id, String password) throws NotFoundException {
        Student authStudent = null;
        String authQueryString = "SELECT U.FirstName, U.LastName " +
                                  "FROM Users U " +
                                  "WHERE U.Id = ? AND U.Password = ?";
        try {
            // Prepare the authentication query
            PreparedStatement pstmt = aConnection.prepareStatement(authQueryString);
            pstmt.setLong(1, id);
            pstmt.setString(2, hashPassword(password));

            // Execute the query
            ResultSet rs = pstmt.executeQuery();

            // If a matching user is found, retrieve the corresponding student
            if (rs.next()) {
                authStudent = retrieve(id);
            } else {
                // If no matching user found, throw NotFoundException
                throw new NotFoundException("Student with ID " + id + " and provided password not found.");
            }

            pstmt.close();
        } catch (SQLException e) {
            // Handle any SQL exceptions
            System.out.println(e.getMessage());
        }

        return authStudent;
    }
    /**
     * Creates a new student record in the system.
     * 
     * @param student The student object containing the information to be inserted.
     * @return true if the student record was successfully created, false otherwise.
     * @throws DuplicateException If a student with the same ID already exists in the system.
     */
    public static boolean create(Student student) throws DuplicateException {
        final long id = student.getId();
        boolean inserted = false;

        // Hash the password
        String hashedPassword = hashPassword(student.getPassword());

       
            try {
                // Call the create method from UserDA to insert the user
                User user = new User(id, hashedPassword, student.getFirstName(), student.getLastName(),
                        student.getEmailAddress(), student.getLastAccess(), student.getEnrolDate(),
                        student.isEnabled(), 's');
                UserDA.create(user);
                // user.create();

                // Now insert the student
                final String sqlInsertStudents = "INSERT INTO students (id, programCode, programDescription, year) " +
                        "VALUES (?, ?, ?, ?)";
                PreparedStatement studentStatement = aConnection.prepareStatement(sqlInsertStudents);
                studentStatement.setLong(1, id);
                studentStatement.setString(2, student.getProgramCode());
                studentStatement.setString(3, student.getProgramDescription());
                studentStatement.setInt(4, student.getYear());
                studentStatement.executeUpdate();

                inserted = true;
            } catch (SQLException | DuplicateException | InvalidUserDataException ee) {
                System.out.println(ee);
            }
        
        return inserted;
    }
    /**
     * Updates the information of a student in the database.
     *
     * @param aStudent Student object representing the student to update.
     * @return Number of records updated in the database.
     */
    
    public static int update(Student aStudent) {
        int records = 0;
        try {
            String sqlUpdateStudent = "UPDATE Students " +
                                        "SET ProgramCode = ?, " +
                                        "ProgramDescription = ?, " +
                                        "Year = ? " +
                                        "WHERE Id = ?";           
    
            PreparedStatement pstmtStudent = aConnection.prepareStatement(sqlUpdateStudent);
            pstmtStudent.setString(1, aStudent.getProgramCode());
            pstmtStudent.setString(2, aStudent.getProgramDescription());
            pstmtStudent.setInt(3, aStudent.getYear());
            pstmtStudent.setLong(4, aStudent.getId());
            records += pstmtStudent.executeUpdate();
    
            pstmtStudent.close();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        try {        
            // User.retrieve(aStudent.getId())

        User user = new User(aStudent.getId(), null, aStudent.getFirstName(), aStudent.getLastName(),
                aStudent.getEmailAddress(), null, null, false, 's');
        records += UserDA.update(user);
        } catch (InvalidUserDataException e) {

        e.printStackTrace();
        }
        return records;
    }
    /**
     * Deletes a student from the database.
     *
     * @param aStudent Student object representing the student to delete.
     * @return Number of records deleted in the database.
     */
    public static int delete(Student aStudent) {
        int records = 0; // Records deleted in method
    
        try {
            // Retrieve the student attribute values
            long id = aStudent.getId();
    
            // Construct SQL delete statements
             String sqlDeleteUser = "DELETE FROM Users WHERE Id = ?";
            String sqlDeleteStudent = "DELETE FROM Students WHERE Id = ?";
    
            // Prepare and execute SQL delete statements
            PreparedStatement pstmtUser = aConnection.prepareStatement(sqlDeleteUser);
            pstmtUser.setLong(1, id);
            records += pstmtUser.executeUpdate();
    
            PreparedStatement pstmtStudent = aConnection.prepareStatement(sqlDeleteStudent);
            pstmtStudent.setLong(1, id);
            records += pstmtStudent.executeUpdate();
    
            pstmtUser.close();
            pstmtStudent.close();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return records;
    }  
    
}
