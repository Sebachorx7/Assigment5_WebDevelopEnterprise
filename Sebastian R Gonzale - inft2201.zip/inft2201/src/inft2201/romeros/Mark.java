package inft2201.romeros;
import java.text.DecimalFormat;

/**
 * Represents a Mark object with attributes related to a student's academic performance.
 */
public class Mark {
	// Properties - Class Attributes.
     /**
     * The minimum allowed GPA.
     */
    public static final float MINIMUM_GPA = 0.0f;
    /**
     * The maximum allowed GPA.
     */
    public static final float MAXIMUM_GPA = 5.0f;
    /**
     * Decimal format for GPA representation.
     */
    public static final DecimalFormat GPA = new DecimalFormat("#0.0");

	// Instance Attributes
    private String courseCode;
    private String courseName;
    private int result;
    private float gpaWeighting;
    /**
     * Gets the course code of the mark.
     *
     * @return the courseCode
     */
	public String getCourseCode() {
		return courseCode;
	}
	/**
     * Sets the course code of the mark.
     *
     * @param courseCode the courseCode to set
     */
	public void setCourseCode(String courseCode) {
		this.courseCode = courseCode;
	}
	/**
     * Gets the course name of the mark.
     *
     * @return the courseName
     */
	public String getCourseName() {
		return courseName;
	}
	/**
     * Sets the course name of the mark.
     *
     * @param courseName the courseName to set
     */
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}
	/**
     * Gets the result of the mark.
     *
     * @return the result
     */
	public int getResult() {
		return result;
	}
	 /**
     * Sets the result of the mark.
     *
     * @param result the result to set
     */
	public void setResult(int result) {
		this.result = result;
	}
	/**
     * Gets the GPA weighting of the mark.
     *
     * @return the gpaWeighting
     */
	public float getGpaWeighting() {
		return gpaWeighting;
	}
	/**
     * Sets the GPA weighting of the mark.
     *
     * @param gpaWeighting the gpaWeighting to set
     */
	public void setGpaWeighting(float gpaWeighting) {
		this.gpaWeighting = gpaWeighting;
	}
	// Parameterized Constructor.
	/**
     * Constructs a Mark object with specified attributes.
     *
     * @param courseCode    The course code associated with the mark.
     * @param courseName    The course name associated with the mark.
     * @param result        The numerical result of the mark.
     * @param gpaWeighting  The GPA weighting of the mark.
     */
	public Mark(String courseCode, String courseName,
				int result, float gpaWeighting) {
		setCourseCode(courseCode);
		setCourseName(courseName);
		setResult(result);
		setGpaWeighting(gpaWeighting);
	}
	//Instance Method
	/**
     * Overrides the toString method to provide formatted mark information.
     *
     * @return Formatted string containing mark information.
     */
	@Override
	public String toString() {
		String outString = "WEBD2201	Web Development - Fundamentals     " + getResult() + "     " + getGpaWeighting();
		return outString;
	}
}
