package inft2201.romeros;
@SuppressWarnings("serial")
/**
 * Custom exception class for handling invalid user ID.
 */
public class InvalidIdException extends Exception {

    /**
     * Constructs an InvalidIdException with a default error message.
     */
		public InvalidIdException() {
			super("Please enter a Valid Id, Id must be positive " + User.ID_NUMBER_LENGHT + " numbers long");
		}
		
		//Parameterized constructor
		/**
	     * Constructs an InvalidIdException with a custom error message.
	     *
	     * @param message The custom error message.
	     */
	    public InvalidIdException(String message) {
	        super(message);
	    }
}
