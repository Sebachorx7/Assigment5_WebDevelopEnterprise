package inft2201.romeros;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * 
 */

public class databasetester {
	// public static void main(String[] args) {
	// 	initialize();
	// 	getUserList();
	// }
	// static String url = "jdbc:postgresql://127.0.0.1:5432/webd4201_db";
	// static Connection aConnection;
	// static String user = "webd4201_admin";
	// static String password = "webd4201_password";
	// /**
	//  * @param args
	//  */
	
		
	// public static Connection initialize()
	// {
	// try
	// {
	// 	// load the JDBC Driver for PostGreSQL
	// 	Class.forName("org.postgresql.Driver");
	// 	// create connection instance
	// 	aConnection = DriverManager.getConnection(url, user, password);
	// }
	// catch (ClassNotFoundException e)
	// //will occur if the driver is not found
	// {
	// 	System.out.println(e);
	// }
	// catch (SQLException e)
	// //will occur if the db does not exist, authentication errors etc.
	// {
	// 	System.out.println(e);
	// }
	// 	return aConnection;
	// }
		
	// public static void getUserList() {
	// 	try {
	// 		Statement stmt = aConnection.createStatement();
	// 		ResultSet rs = stmt.executeQuery("SELECT * FROM users;");
	// 		while (rs.next()) {
	// 			String out = String.format("id: %s\nname: %s", rs.getInt("id"), rs.getString("firstname"));
	// 			System.out.println(out);
	// 		}
	// 	} catch (SQLException ex) {
	// 		System.out.println(ex.getMessage());
	// 	}
	// }
	
	// public static void createUser(String name) {
	// 	try {
	// 		String sql = "INSERT INTO users (name) VALUES (?);";
	// 		PreparedStatement stmt = aConnection.prepareStatement(sql);
	// 		stmt.setString(1,  name);
	// 		stmt.executeQuery();
	// 	} catch (SQLException ex)
	// 	{
	// 		System.out.println(ex.getMessage());
	// 		}
	// 	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		initialize();
		// getUserList();
		retrieve(100111112);
//		createUser("osvaldo");
		

	}
	static String url = "jdbc:postgresql://127.0.0.1:5432/inft2201_db";
	static Connection aConnection;
	static String user = "inft2201_admin";
	static String password = "inft2201_password";
	public static Connection initialize()
	{
	try
	{
	// load the JDBC Driver for PostGreSQL
	Class.forName("org.postgresql.Driver");
	// create connection instance
	aConnection = DriverManager.getConnection(url, user,
	password);
	}
	catch (ClassNotFoundException e)
	//will occur if the driver is not found
	{
	System.out.println(e);
	}
	catch (SQLException e)
	//will occur if the db does not exist, authentication errors etc.
	{
	System.out.println(e);
	}
	return aConnection;
	}
	
	public static void getUserList() {
		try {
			Statement stmt = aConnection.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT * FROM users;");
			while (rs.next()) {
				String out = String.format("id: %s\nname: %s", rs.getInt("id"), rs.getString("firstname"));
				System.out.println(out);
			}
		} catch(SQLException ex) {
			System.out.println(ex.getMessage());
		}
	}
	
	public static void createUser(String name) {
		try {
			String sql = "INSERT INTO USERS (name) VALUES (?)";
			PreparedStatement stmt = aConnection.prepareStatement(sql);
			stmt.setString(1, name);
			stmt.executeQuery();
			
		} catch(SQLException ex) {
			System.out.println(ex.getMessage());
		}
	}

	//nuevo para boorrar despues

	public static void retrieve(long id){
        // Define the SQL query statement
        String sqlQuery = "SELECT id, firstname, lastname " +
                          "FROM users " +
                          "WHERE Id = '" + id + "'";

		String sqlQuery2 = "SELECT *" +
							"FROM students " +
							"WHERE Id = '" + id + "'"; 
		try {
			Statement stmt = aConnection.createStatement();
			ResultSet rs = stmt.executeQuery(sqlQuery);
			while (rs.next()) {
				// Extract the data from the first query
				String out = String.format("id: %s\nname: %s %s", rs.getInt("id"), rs.getString("firstname"), rs.getString("lastname"));
				System.out.println(out);
			}
			
			// Create a new Statement object for the second query
			Statement stmt2 = aConnection.createStatement();
			ResultSet rs2 = stmt2.executeQuery(sqlQuery2);
			while (rs2.next()) {
				// Extract the data from the second query
				String out2 = String.format("program description: %s", rs2.getString("programDescription"));
				System.out.println(out2);
			}
		} catch (SQLException ex) {
			System.out.println(ex.getMessage());
		}
    }






}
