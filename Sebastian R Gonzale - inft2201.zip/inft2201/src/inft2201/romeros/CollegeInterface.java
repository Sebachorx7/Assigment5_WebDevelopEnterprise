package inft2201.romeros;

/**
 * This interface represents a college and defines constants related to Durham College.
 */
public interface CollegeInterface {
	/**
     * The name of the college.
     */
	static final String COLLEGE_NAME = "Durham College";
     /**
     * The phone number of the college.
     */
	static final String PHONE_NUMBER = "(905)721-2000";
	/**
     * Abstract method to retrieve the type of the college for display purposes.
     *
     * @return a String representing the type of the college.
     */
	public abstract String getTypeForDisplay();
}
