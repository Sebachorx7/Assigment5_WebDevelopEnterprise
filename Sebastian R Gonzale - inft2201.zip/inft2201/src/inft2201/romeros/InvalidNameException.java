package inft2201.romeros;
@SuppressWarnings("serial")
/**
 * Custom exception class for handling invalid names.
 */
public class InvalidNameException extends Exception {
	// Default constructor
	/**
     * Constructs an InvalidNameException with a default error message.
     */
	public InvalidNameException() {
        super("Error: Invalid name format. The name cannot be empty or contain numeric characters.");
    }
	//Parameterized constructor
	/**
     * Constructs an InvalidNameException with a custom error message.
     *
     * @param message The custom error message.
     */
    public InvalidNameException(String message) {
        super(message);
    }
}
