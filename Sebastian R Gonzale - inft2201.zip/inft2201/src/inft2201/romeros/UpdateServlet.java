package inft2201.romeros;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.util.Date;
/**
 * Servlet for updating user information.
 */
public class UpdateServlet extends HttpServlet {

    /**
     * Handles HTTP POST requests.
     *
     * @param request  the HTTP request
     * @param response the HTTP response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException      if an I/O error occurs
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Connection c = null;
        try {
            // Initialize database connection
            c = DatabaseConnect.initialize();
            Student.initialize(c);
            User.initialize(c);

            // Retrieve form parameters
            // Messages to be displayed in Tomcat
            System.out.println("Getting form parameters...");

            String idString = request.getParameter("userId");
            long id = Long.parseLong(idString);
            String password = request.getParameter("password");
            String firstName = request.getParameter("firstName");
            String lastName = request.getParameter("lastName");
            String emailAddress = request.getParameter("emailAddress");
            Date lastAccess = new Date();
            Date enrolDate = new Date();
            String enable = request.getParameter("enable");
            boolean enablebool = Boolean.parseBoolean(enable);
            String type = request.getParameter("type");
            char typechar = type.charAt(0);
            // Messages to be displayed in Tomcat
            System.out.println("Form parameters obtained...");

            // Create updated user object
            User userUpdated = new User(id, password, firstName, lastName, emailAddress, lastAccess, enrolDate, enablebool, typechar);
            // Messages to be displayed in Tomcat
            System.out.println("First Name: " + firstName);
            System.out.println("Last Name: " + lastName);
            System.out.println("Email Address: " + emailAddress);
            System.out.println("Printing user." + userUpdated);

            // Set user properties
            userUpdated.setFirstName(firstName);
            userUpdated.setLastName(lastName);
            userUpdated.setEmailAddress(emailAddress);

            // Update user in database
            int updateSuccess = UserDA.update(userUpdated);
            if (updateSuccess != 0) {
                // Set session attribute and request attribute for success message
                HttpSession session = request.getSession();
                session.setAttribute("updatedUser", userUpdated);
                request.setAttribute("successMessage", "User update successful.");
                // Forward to admin.jsp
                request.getRequestDispatcher("admin.jsp").forward(request, response);
                System.out.println("User update successful. Redirecting to administrative dashboard.");
            } else {
                // Set request attribute for error message
                String error = "Failed to update user in the database.";
                request.setAttribute("error", error);
                // Forward to edit.jsp
                request.getRequestDispatcher("edit.jsp").forward(request, response);
                System.out.println("User update failed. Redirecting back to edit page.");
            }
        } catch (Exception e) {
            // Handle exception
            e.printStackTrace();
            request.setAttribute("error", "Error occurred during password hashing.");
            request.getRequestDispatcher("register.jsp").forward(request, response);
            System.out.println("Error occurred during user update. Redirecting back to edit page.");
        }
    }

    /**
     * Handles HTTP GET requests.
     *
     * @param request  the HTTP request
     * @param response the HTTP response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException      if an I/O error occurs
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Forward to doPost method
        doPost(request, response);
    }
}
