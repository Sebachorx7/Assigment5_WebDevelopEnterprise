package inft2201.romeros;

import java.io.*;
import java.sql.Connection;
import javax.servlet.*;
import javax.servlet.http.*;
/**
 * The LoginServlet class handles user login requests.
 */
public class LoginServlet extends HttpServlet {

    /**
     * Formats error page to display error message.
     * @param errorMessage The error message to display.
     * @param response The HttpServletResponse object to write response.
     * @throws IOException If an I/O error occurs while writing response.
     */
    private void formatErrorPage(String errorMessage, HttpServletResponse response) throws IOException {
        PrintWriter output = response.getWriter();
        response.setContentType("text/html");
        output.println("<h2>Error</h2>");
        output.println("<p>" + errorMessage + "</p>");
        output.close();
    }

    /**
     * Handles POST requests to authenticate user login.
     * @param request The HttpServletRequest object containing user login information.
     * @param response The HttpServletResponse object to send response.
     * @throws ServletException If the servlet encounters difficulty handling the request.
     * @throws IOException If an I/O error occurs while handling the request.
     */
    public void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        HttpSession session = request.getSession(true);
        try {
            // Establish database connection
            Connection c = null;
            c = DatabaseConnect.initialize();
            Student.initialize(c);
            User.initialize(c);
            
            // Retrieve login credentials from request parameters
            String login = request.getParameter("Login");
            String password = request.getParameter("password");
            System.out.println(login);
            try {
                Long l = Long.parseLong(login);
                long adminlog = 999999999;
            
                // Authenticate user
                Student authStudent = Student.authenticate(l, password);
                
                if (authStudent != null) {
                    // Set authenticated student object and clear errors in session
                    session.setAttribute("student", authStudent);
                    session.setAttribute("errors", "");
                    session.setAttribute("loggedInUsername", authStudent.getFirstName());
                    session.setAttribute("loggedinUserId", authStudent.getId());
                    // Redirect user to dashboard
                    if (l == adminlog) {
                        response.sendRedirect("./admin.jsp");
                    } else {
                        response.sendRedirect("./dashboard.jsp");
                    }
                } else {
                    response.sendRedirect("./login.jsp");
                }
            } catch(NotFoundException nfe) {
                // Handle authentication failure
                String error = "Your login information is incorrect. Please try again.";
                session.setAttribute("error", error);
                response.sendRedirect("./login.jsp");
            }
        } catch (Exception e) {
            // Handle database connection or other network errors
            String error = "A network error has occurred! Please notify your system administrator and check log. " + e.getMessage();
            formatErrorPage(error, response);
            e.printStackTrace();
        }
    }

    /**
     * Handles GET requests by delegating to doPost method.
     * @param request The HttpServletRequest object containing request information.
     * @param response The HttpServletResponse object to send response.
     * @throws ServletException If the servlet encounters difficulty handling the request.
     * @throws IOException If an I/O error occurs while handling the request.
     */
    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doPost(request, response);
    }
}