package inft2201.romeros;  //change this to make the class part of your package

/**
 * Main method to test the first part of Assignment 1
 * 
 * @author Darren Puffer
 * @version 1.0 (Janaury 8th, 2019)
 * @version 1.1 (January 11th, 2023) (Revised by Clint MacDonald)
 * @version 1.2 (January 25th, 2024) (Revised by Adam Kunz)
 * @since 1.0
 */
import java.util.*;

public class Lab1Tester {
	
	public static final String ANSI_RESET = "\u001B[0m";
	public static final String ANSI_RED = "\u001B[31m";
	public static final String ANSI_GREEN = "\u001B[32m";
	public static final String ANSI_YELLOW = "\u001B[33m";
	public static final String ANSI_CYAN = "\u001B[36m";

	public static GregorianCalendar cal = new GregorianCalendar();
	public static Date lastAccess;
	public static Date enrol;
	public static Student student1;
	public static Faculty professor;
	public static long possibleId = 100123456L;

	public static int score = 0;

	public static void main(String[] args) throws InvalidIdException, InvalidPasswordException, InvalidNameException {
		
		// we'll use the same dates for everyone
		cal.set(2016, Calendar.SEPTEMBER, 3);
		lastAccess = cal.getTime();
		enrol = cal.getTime();

		System.out.println(ANSI_CYAN + "\n\n******************** Deliverable 1 Output ********************\n");
		System.out.println("********************************************************************************");
		System.out.println("NOTE: any exceptions displayed while instantiating Student objects in the program only display the contents " +
							"of the Exception, by using the getMessage() method.");
		System.out.println("********************************************************************************" + ANSI_RESET);
		
		testShortId();		
		testLongId();
		testBadId();
		testShortPassword();
		testLongPassword();
		testGoodStudent();

		System.out.println(ANSI_CYAN + "********************************************************************************");
		System.out.println("NOTE: any exceptions displayed while instantiating Faculty objects will call the toString() method, " +
							"this includes the Exception type as part of the message.");
		System.out.println("********************************************************************************");
		
		System.out.println("\nThe following object instantiations will use a Faculty object passing a String for the id (where there could be parsing issues).\n" + ANSI_RESET);
		
		testGoodFaculty();
		testBadFirstName();

		System.out.println(ANSI_CYAN + String.format("\n\nPerformed 8 tests.  Your code made it to the right spot %s times.", score));
		if (score == 8) {
			System.out.println("YOU WIN!!");
		}
		System.out.println("Make sure to check your messages are all spelled correctly and make sense!" + ANSI_RESET);
	}

	public static void testShortId() {
		System.out.println(
				ANSI_YELLOW + "\nThe following will cause an Exception based on student id being too small (123L).");
		System.out.println(ANSI_RESET + "Trying to instantiate a random student before displaying it, passing:"
				+ "\n\tStudent student1 = new Student(123L, \"password\", \"Robert\", \"McReady\","
				+ " \"bob.mcready@dcmail.ca\", enrol, lastAccess, 's', true, \"CPA\", \"Computer Programmer Analyst\", 3);\n");
		try {
			student1 = new Student(
					123L,
					"password",
					"Robert",
					"McReady",
					"bob.mcready@dcmail.ca",
					enrol,
					lastAccess,
					true,
					's',
					"CPA",
					"Computer Programmer Analyst",
					3);
			System.out.print(ANSI_RED);
			student1.dump();
			System.out.print(ANSI_RESET);
		} catch (InvalidUserDataException iude) {
			System.out.println(ANSI_GREEN + iude.getMessage() + ANSI_RESET);
			score += 1;
		}
	}

	public static void testLongId() {
		System.out.println(ANSI_YELLOW
				+ "\nThe following will cause an Exception based on student id being too big (10012345678L).");
		System.out.println(ANSI_RESET + "Trying to instantiating a random student before displaying it, passing:\n\t"
				+ "Student student1 = new Student(10012345678L, \"password\", \"Robert\", \"McReady\","
				+ " \"bob.mcready@dcmail.ca\", enrol, lastAccess, 's', true, \"CPA\", \"Computer Programmer Analyst\", 3);\n");
		try {
			student1 = new Student(
					10012345678L,
					"password",
					"Robert",
					"McReady",
					"bob.mcready@dcmail.ca",
					enrol,
					lastAccess,
					true,
					's',
					"CPA",
					"Computer Programmer Analyst",
					3);
			System.out.print(ANSI_RED);
			student1.dump();
			System.out.print(ANSI_RESET);
		} catch (InvalidUserDataException iude) {
			System.out.println(ANSI_GREEN + iude.getMessage() + ANSI_RESET);
			score += 1;
		}
	}

	public static void testShortPassword() {
		System.out.println(
				ANSI_YELLOW + "\nThe following will cause an Exception based on password being too small (tiny).");
		System.out.println(ANSI_RESET + "Trying to instantiating a random student before displaying it, passing:\n\t"
				+ "Student student1 = new Student(100123456L, \"tiny\", \"Robert\", \"McReady\","
				+ " \"bob.mcready@dcmail.ca\", enrol, lastAccess, 's', true, \"CPA\", \"Computer Programmer Analyst\", 3);\n");

		try {
			student1 = new Student(
					100123456L,
					"tiny",
					"Robert",
					"McReady",
					"bob.mcready@dcmail.ca",
					enrol,
					lastAccess,
					true,
					's',
					"CPA",
					"Computer Programmer Analyst",
					3);
			System.out.print(ANSI_RED);
			student1.dump();
			System.out.print(ANSI_RESET);
		} catch (InvalidUserDataException ex) {
			System.out.println(ANSI_GREEN + ex.getMessage() + ANSI_RESET);
			score += 1;
		}
	}

	public static void testLongPassword() {
		System.out.println(ANSI_YELLOW
				+ "\nThe following will cause an Exception based on password being too long (supercrazylongpasswordthatisactuallyreallylongerthanwhatweaskedfor).");
		System.out.println(ANSI_RESET + "Trying to instantiating a random student before displaying it, passing:\n\t"
				+ "Student student1 = new Student(100123456L, \"tiny\", \"Robert\", \"McReady\","
				+ " \"bob.mcready@dcmail.ca\", enrol, lastAccess, 's', true, \"CPA\", \"Computer Programmer Analyst\", 3);\n");

		try {
			student1 = new Student(
					100123456L,
					"supercrazylongpasswordthatisactuallyreallylongerthanwhatweaskedfor",
					"Robert",
					"McReady",
					"bob.mcready@dcmail.ca",
					enrol,
					lastAccess,
					true,
					's',
					"CPA",
					"Computer Programmer Analyst",
					3);
			System.out.print(ANSI_RED);
			student1.dump();
			System.out.print(ANSI_RESET);
		} catch (InvalidUserDataException ex) {
			System.out.println(ANSI_GREEN + ex.getMessage() + ANSI_RESET);
			score += 1;
		}
	}

	public static void testBadId() {
		System.out
				.println(ANSI_YELLOW + "\nThe following will cause an Exception based on an incorrectly formatted id (-100123456L).");
		System.out.println(ANSI_RESET + "Trying to instantiating a random student before displaying it, passing:\n\t"
				+ "Student student1 = new Student(-100123456L, \"password\", \"Robert\", \"McReady\","
				+ " \"bob.mcready@dcmail.ca\", enrol, lastAccess, 's', true, \"CPA\", \"Computer Programmer Analyst\", 3);\n");

		try {
			student1 = new Student(
					-100123456L,
					"password",
					"Robert",
					"McReady",
					"bob.mcready@dcmail.ca",
					enrol,
					lastAccess,
					true,
					's',
					"CPA",
					"Computer Programmer Analyst",
					3);
			System.out.print(ANSI_RED);
			student1.dump();
			System.out.print(ANSI_RESET);
		} catch (InvalidUserDataException ex) {
			System.out.println(ANSI_GREEN + ex.getMessage() + ANSI_RESET);
			score += 1;
		}
	}

	public static void testGoodStudent() {
		System.out.println(ANSI_YELLOW + "\nThe following will not cause an exception.");
		System.out.println(ANSI_RESET + "Trying to instantiating a random student before displaying it, passing:\n\t"
				+ "Student student1 = new Student(100123456L, \"password\", \"Robert\", \"McReady\","
				+ " \"bob.mcready@dcmail.ca\", enrol, lastAccess, 's', true, \"CPA\", \"Computer Programmer Analyst\", 3);\n");
		try {
			student1 = new Student(
					100123456L,
					"password",
					"Robert",
					"McReady",
					"bob.mcready@dcmail.ca",
					enrol,
					lastAccess,
					true,
					's',
					"CPA",
					"Computer Programmer Analyst",
					3);
			System.out.print(ANSI_GREEN);
			student1.dump();
			System.out.print(ANSI_RESET);
			score += 1;
		} catch (InvalidUserDataException iude) {
			System.out.println(iude.getMessage());
		}
	}

	public static void testGoodFaculty() {
		System.out.println(ANSI_YELLOW + "\nThe following will not cause an exception.");
		System.out.println(ANSI_RESET + "Trying to instantiate my professor before displaying it, passing:\n\t"
				+ "professor = new Faculty(\"" + possibleId + "\", \"another password\", \"Adam\", \"Kunz\", "
				+ "\"adam.kunz@durhamcollege.ca\", enrol, lastAccess, 'f', true, "
				+ "\"SEIT\", \"Faculty of Science, Engineering, and Information Technology\", \"H-140\", 2044);\n");
		try {
			professor = new Faculty(possibleId, "another password", "Adam", "Kunz", "adam.kunz@durhamcollege.ca", enrol,
					lastAccess, true, 'f',
					"SEIT", "Faculty of Science, Engineering, and Information Technology", "H-140", 2044);
			System.out.print(ANSI_GREEN);
			professor.dump();
			System.out.print(ANSI_RESET);
			score += 1;
		} catch (InvalidUserDataException ide) {
			System.out.println(
					"Problem creating a professor with an id of: \"" + possibleId + "\"\n\t " + ide.toString());

		}
	}

	public static void testBadFirstName() {
		System.out.println(ANSI_YELLOW + "\nThe following will cause an InvalidUserDataException based on a missing first name");
		System.out.println("The program demonstrates that InvalidUserDataException (in fact any/all Exceptions) can be caught by the generic Exception catch");
		System.out.println(ANSI_RESET + "\nTrying to instantiate my professor before displaying it, passing:\n\t"
			+ "professor = new Faculty(\"" + possibleId + "\", \"somepassword\", \"\", \"Kunz\", " 
			+ "\"adam.kunz@durhamcollege.ca\", enrol, lastAccess, 'f', true, " 
			+ "\"SEIT\", \"Faculty of Science, Engineering, and Information Technology\", \"H-140\", 2044);\n");
		try {
			professor = new Faculty(possibleId, "somepassword", "", "Kunz", "adam.kunz@durhamcollege.ca", enrol,
					lastAccess, true, 'f',
					"SEIT", "Faculty of Science, Engineering, and Information Technology", "H-140", 2044);
			System.out.print(ANSI_RED);
			professor.dump();
			System.out.print(ANSI_RESET);
		} catch (Exception e) {
			System.out.println(ANSI_GREEN + "Problem creating a professor with an id of: \"" + possibleId + "\"\n\t " + e.toString() + ANSI_RESET);
			score += 1;
		}
	}
}
