package inft2201.romeros;
import java.sql.*;
/**
 * The DatabaseConnect class manages the connection to a PostgreSQL database.
 * It includes methods for establishing and terminating the database connection.
 */
 public class DatabaseConnect
 {
     /**
      * Database location
      */
      static String url = "jdbc:postgresql://127.0.0.1:5432/inft2201_db";
     /**
      * Connection object to open port to db
      */
      static Connection aConnection;
     /**
      * database user
      */
      static String user = "inft2201_admin";
     /**
      * database user password
      */
     static String password = "inft2201_password";
     /**
     * Establishes the database connection.
     *
     * @return Connection to the inft2201_db database.
     * @throws SQLException If a database access error occurs or the URL is null.
     */
    public static Connection initialize()
	{
		try
 		{ 	// load the jdbc - odbc Driver for PostGreSQL
			Class.forName("org.postgresql.Driver");
			
			// create connection instance
	    	aConnection = DriverManager.getConnection(url, user, password);
	    	
	 	}
		catch (ClassNotFoundException e)
		{
			System.out.println(e);
		}
		catch (SQLException e)
			{ System.out.println(e); }
		return aConnection;
	}

	// close the database connection
	public static void terminate()
	{
		try
 		{
    		aConnection.close();
		}
		catch (SQLException e)
			{ System.out.println(e);	}
	}
    /**
     * Executes an SQL query with optional parameters.
     * @param query The SQL query to execute.
     * @param params The optional parameters to be set in the prepared statement.
     * @throws SQLException If a database access error occurs or the URL is null.
     */
    public static void execute(String query, Object... params) throws SQLException {
        try (Connection connection = initialize();
            PreparedStatement statement = connection.prepareStatement(query)) {
            
            // Set parameters in the prepared statement
            for (int i = 0; i < params.length; i++) {
                statement.setObject(i + 1, params[i]);
            }
            
            // Execute the SQL query
            statement.executeUpdate();
        }
    }
 }
 