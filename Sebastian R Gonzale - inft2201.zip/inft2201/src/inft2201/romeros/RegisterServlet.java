package inft2201.romeros;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.sql.Connection;
import java.util.Date;
import javax.servlet.ServletException;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
/**
 * Servlet implementation class RegisterServlet
 * Handles registration requests
 */

public class RegisterServlet extends HttpServlet {
    
    /**
     * Handles POST requests for registration
     */
    Connection c;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        System.out.println("Processing registration request...");

        // Retrieve form data
        String idString = request.getParameter("id");
        long id = Long.parseLong(idString);
        String password = request.getParameter("password");
        String firstName = request.getParameter("firstName");
        String lastName = request.getParameter("lastName");
        String emailAddress = request.getParameter("emailAddress"); 
        System.out.println("Email Address received: " + emailAddress);
        String programCode = request.getParameter("programCode");
        String programDescription = request.getParameter("programDescription");
        String yearString = request.getParameter("year");
        int year = Integer.parseInt(yearString);
        
        System.out.println("Received registration data:");
        System.out.println("ID: " + id);
        System.out.println("password: " + password);
        System.out.println("First Name: " + firstName);
        System.out.println("Last Name: " + lastName);
        System.out.println("Email Address: " + emailAddress);
        System.out.println("Program Code: " + programCode);
        System.out.println("Program Description: " + programDescription);
        System.out.println("Year: " + year);
        
        // Perform server-side validation
        if (id <= 0  || password == null || firstName == null || firstName.isEmpty() || lastName == null || lastName.isEmpty() || emailAddress == null || emailAddress.isEmpty() || year <= 0) {
            // Set error message
            request.setAttribute("error", "Please fill in all required fields.");
            // Forward back to register.jsp with error message
            request.getRequestDispatcher("register.jsp").forward(request, response);
            System.out.println("Validation failed. Redirecting back to registration page.");
            return;
        } else {
            // Perform more validation as needed
        
            try {

                c = DatabaseConnect.initialize();
                Student.initialize(c);
                User.initialize(c);
                // Hash the password
                String hashedPassword = hashPassword(password);
                
                // Set enrollment date and last access date
                Date today = new Date();
                
                // Create new user record
                Student newStudent = new Student(id, hashedPassword, firstName, lastName, emailAddress, today, today, true, 's', programCode, programDescription, year);

                // Store the new student in the database
                boolean insertionSuccess = StudentDA.create(newStudent);
                
                if (insertionSuccess) {
                    // Store the new student in session
                    HttpSession session = request.getSession();
                    session.setAttribute("loggedInUser", newStudent);
                    // Redirect to dashboard.jsp
                    response.sendRedirect("login.jsp");
                    System.out.println("User registration successful. Redirecting to dashboard.");
                } else {
                    // Handle insertion failure
                    String error = "Failed to register user in the database.";
                    request.setAttribute("error", error);
                    request.getRequestDispatcher("register.jsp").forward(request, response);
                    System.out.println("User registration failed. Redirecting back to registration page.");
                }
            } catch (NoSuchAlgorithmException | InvalidKeySpecException | InvalidUserDataException | DuplicateException e) {
                // Handle hashing exception
                e.printStackTrace();
                // Set error message
                request.setAttribute("error", "Error occurred during password hashing.");
                // Forward back to register.jsp with error message
                request.getRequestDispatcher("register.jsp").forward(request, response);
                System.out.println("Error occurred during user registration. Redirecting back to registration page.");
            }
        }
    }
    
    /**
     * Method to hash the password 
     * @param password The password to hash
     * @return The hashed password
     * @throws NoSuchAlgorithmException
     * @throws InvalidKeySpecException
     */
    private String hashPassword(String password) throws NoSuchAlgorithmException, InvalidKeySpecException {
        return password; 
    }
}