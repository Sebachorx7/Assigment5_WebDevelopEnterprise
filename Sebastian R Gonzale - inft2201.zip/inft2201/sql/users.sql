-- Name: Sebastian Romero Gonzalez
-- Date: February 14, 2024
-- Course code: Inft2201
-- Description: SQL file with commands for creating, modifying, and querying
-- data related to the users of an educational institution.
DROP TABLE IF EXISTS users CASCADE;
CREATE EXTENSION IF NOT EXISTS pgcrypto;
DROP SEQUENCE IF EXISTS users_id_seq CASCADE;
--CREATE SEQUENCE users_id_seq START 100111111;

CREATE TABLE users(
    Id INT PRIMARY KEY,-- DEFAULT nextval('users_id_seq'),
    Password VARCHAR(40) NOT NULL,
    FirstName VARCHAR(128),
    LastName VARCHAR(128),
    EmailAddress VARCHAR(255) UNIQUE,
    lastAccess TIMESTAMP,
    enrolDate TIMESTAMP,
    enabled BOOLEAN,
    type VARCHAR(2)
);

INSERT INTO users (Id,password, firstName, lastName, emailAddress, lastAccess,enrolDate,enabled,type)
VALUES

('100111111', encode(digest('password', 'sha1'),'hex'), 'Mike', 'Jones', 'mike.jones@example.com', CURRENT_DATE, '2024-02-15', true, 's'),
('100222222', encode(digest('password', 'sha1'),'hex'), 'Sebastian', 'Gonzalez', 'sebastian.romerogonzalez@dcmail.ca', CURRENT_DATE, '2024-02-15', true, 's'),
('100333333', encode(digest('password', 'sha1'),'hex'), 'Michael', 'Jackson', 'm.jackson@example.com', CURRENT_DATE, '2024-02-15', true, 's'),
('100444444', encode(digest('password', 'sha1'),'hex'), 'Brad', 'Pitt', 'b.pitt@example.com', CURRENT_DATE, '2024-02-15', true, 'f'),
('100555555', encode(digest('password', 'sha1'),'hex'), 'Jennifer', 'Aniston', 'j.aniston@example.com', CURRENT_DATE, '2024-02-15', true, 'f'),
('100666666', encode(digest('password', 'sha1'),'hex'), 'Leonardo', 'DiCaprio', 'l.dicaprio@example.com', CURRENT_DATE, '2024-02-15', true, 'f'),
('999999999', encode(digest('mypassword', 'sha1'),'hex'), 'Admin', 'Admin', 'admin@admin.ca', CURRENT_DATE, '2024-04-17', true, 'f');
SELECT * FROM users;