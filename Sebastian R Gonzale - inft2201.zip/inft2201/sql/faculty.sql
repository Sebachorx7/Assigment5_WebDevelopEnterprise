-- Name: Sebastian Romero Gonzalez
-- Date: February 14, 2024
-- Course code: Inft2201
-- Description: SQL file with commands for creating, modifying, and querying
-- data related to the faculty of an educational institution.

DROP TABLE IF EXISTS faculty CASCADE;
CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE TABLE faculty(
    Id INT PRIMARY KEY,    
    SchoolCode VARCHAR(128),
    SchoolDescription VARCHAR(128),
    Office VARCHAR(128),
    Extension INT,
    FOREIGN KEY (id) REFERENCES users(id)
);
INSERT INTO faculty (Id, SchoolCode, SchoolDescription, Office, Extension)
VALUES
(100444444, 'BITM', 'Bussiness Information Technology Management','H140', 1010),
(100555555, 'EAS', 'Engineering and Architectural Science','B280', 1521),
(100666666, 'FOA', 'Faculty of Arts','B110', 1112);
SELECT * FROM faculty;