-- Name: Sebastian Romero Gonzalez
-- Date: February 14, 2024
-- Course code: Inft2201
-- Description: SQL file with commands for creating, modifying, and querying
-- data related to the students of an educational institution.

DROP TABLE IF EXISTS students CASCADE;
CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE TABLE students(
    Id INT PRIMARY KEY,    
    ProgramCode VARCHAR(128),
    ProgramDescription VARCHAR(128),
    Year INT,
    FOREIGN KEY (id) REFERENCES users(id)
);
INSERT INTO students (Id, ProgramCode, ProgramDescription, Year)
VALUES
(100111111, 'CPA', 'Computer Programmer Analyst', 3),
(100222222, 'ECE', 'Electrical and Computer Engineering', 2),
(100333333, 'MP', 'Media Production ', 2);
SELECT * FROM students;